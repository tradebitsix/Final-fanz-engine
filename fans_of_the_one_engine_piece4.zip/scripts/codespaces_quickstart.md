# GitHub Codespaces quickstart
1) Create Codespace
2) In terminal:
```bash
docker compose up --build
```
3) Open ports 5173 and 8000
